/**
 * Mougle Production Preview Studio — routes.
 *
 * Every route is root-admin gated. All outputs are draft / internal-only.
 * Never opens a socket, never publishes, never renders.
 */

import type { Express, RequestHandler } from "express";
import {
  PreviewStudioGenerateInputSchema,
  PreviewStudioUpdateControlsInputSchema,
} from "../../shared/production-house";
import {
  generatePreviewStudioState,
  getDefaultStudioScenes,
  getLatestPreviewStudioState,
  getPreviewStudioTooltips,
  listPreviewStudioStates,
  updatePreviewStudioControls,
} from "../services/preview-studio-service";

export function registerPreviewStudioRoutes(
  app: Express,
  requireRootAdmin: RequestHandler,
): void {
  const PREFIX = "/api/admin/production-house/preview-studio";

  app.get(`${PREFIX}/state`, requireRootAdmin, (_req, res) => {
    return res.json({ ok: true, state: getLatestPreviewStudioState() });
  });

  app.get(`${PREFIX}/defaults`, requireRootAdmin, (_req, res) => {
    return res.json({ ok: true, defaults: getDefaultStudioScenes() });
  });

  app.get(`${PREFIX}/tooltips`, requireRootAdmin, (_req, res) => {
    return res.json({ ok: true, tooltips: getPreviewStudioTooltips() });
  });

  app.get(`${PREFIX}/history`, requireRootAdmin, (_req, res) => {
    return res.json({ ok: true, states: listPreviewStudioStates() });
  });

  app.post(`${PREFIX}/generate`, requireRootAdmin, (req, res) => {
    const parsed = PreviewStudioGenerateInputSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ ok: false, error: "invalid_body", issues: parsed.error.issues });
    }
    const state = generatePreviewStudioState(parsed.data.controls);
    return res.json({ ok: true, state });
  });

  app.post(`${PREFIX}/update-controls`, requireRootAdmin, (req, res) => {
    const parsed = PreviewStudioUpdateControlsInputSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ ok: false, error: "invalid_body", issues: parsed.error.issues });
    }
    const state = updatePreviewStudioControls(parsed.data.controls);
    return res.json({ ok: true, state });
  });
}
