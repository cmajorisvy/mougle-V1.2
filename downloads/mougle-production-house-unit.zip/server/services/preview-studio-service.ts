/**
 * Mougle Production Preview Studio — admin-only, dry-run, never published.
 *
 * SAFETY:
 *   - This module NEVER calls a provider, opens a socket, renders anything,
 *     writes to public storage, or generates a public/signed URL.
 *   - Every output carries the locked safety fields (status: "draft",
 *     visibility: "admin_only_internal", publicUrl/signedUrl: null,
 *     realSendAllowed/executionEnabled: false, noUnrealExecution/
 *     noFourDHardware: true) and the SAFETY_ENVELOPE from
 *     shared/production-house.ts.
 *   - State is held in-memory only; nothing is written to disk or DB.
 */

import { randomUUID } from "crypto";
import {
  PREVIEW_STUDIO_MODES,
  SAFETY_ENVELOPE,
  type PreviewStudioControls,
  type PreviewStudioMode,
  type PreviewStudioScene,
  type PreviewStudioState,
} from "../../shared/production-house";

interface ModeDefault {
  label: string;
  roomLabel: string;
  layoutPreset: PreviewStudioControls["layoutPreset"];
  camera: PreviewStudioControls["camera"];
  lighting: PreviewStudioControls["lighting"];
  aspect: "16:9" | "9:16" | "1:1" | "21:9";
  accent: string;
  lightingLabel: string;
  tickerText: string;
  lowerThirdText: string;
  avatars: Array<{ label: string; role: string; x: number; y: number; facing: "camera" | "left" | "right" | "center" }>;
  panels: Array<{
    label: string;
    kind: "panel" | "ledwall" | "ticker" | "lower_third" | "callout" | "monitor";
    x: number; y: number; w: number; h: number;
  }>;
  fourDCues: Array<{ label: string; tSec: number; effect: string }>;
  notes: string[];
}

const MODE_DEFAULTS: Record<PreviewStudioMode, ModeDefault> = {
  newsroom: {
    label: "Newsroom Preview",
    roomLabel: "Mougle Newsroom Studio A",
    layoutPreset: "anchor_left_panel_right",
    camera: "anchor_two_shot",
    lighting: "neutral_news",
    aspect: "16:9",
    accent: "#38bdf8",
    lightingLabel: "Neutral newsroom key + soft fill",
    tickerText: "MOUGLE INTELLIGENCE NETWORK • LIVE PREVIEW • ADMIN ONLY",
    lowerThirdText: "Anchor — Mougle News Desk",
    avatars: [
      { label: "Anchor", role: "news_anchor", x: 0.32, y: 0.62, facing: "camera" },
      { label: "Co-Anchor", role: "news_anchor", x: 0.46, y: 0.62, facing: "camera" },
    ],
    panels: [
      { label: "LED Wall", kind: "ledwall", x: 0.04, y: 0.08, w: 0.92, h: 0.42 },
      { label: "Topic Panel", kind: "panel", x: 0.62, y: 0.18, w: 0.30, h: 0.28 },
      { label: "Lower Third", kind: "lower_third", x: 0.04, y: 0.80, w: 0.55, h: 0.10 },
      { label: "Ticker", kind: "ticker", x: 0.0, y: 0.92, w: 1.0, h: 0.06 },
    ],
    fourDCues: [
      { label: "Open sting", tSec: 0, effect: "light_flash" },
      { label: "Topic change", tSec: 18, effect: "color_change" },
    ],
    notes: ["Default newsroom layout. Edit avatars or LED-wall topic in the right inspector."],
  },
  breaking_news: {
    label: "Breaking News Preview",
    roomLabel: "Breaking News Override",
    layoutPreset: "breaking_news_alert",
    camera: "anchor_close_up",
    lighting: "breaking_high_contrast",
    aspect: "16:9",
    accent: "#f43f5e",
    lightingLabel: "High-contrast red key, urgency mood",
    tickerText: "BREAKING • PREVIEW ONLY • NOT PUBLISHED",
    lowerThirdText: "BREAKING — Mougle Network",
    avatars: [
      { label: "Anchor", role: "news_anchor", x: 0.40, y: 0.60, facing: "camera" },
    ],
    panels: [
      { label: "Alert LED Wall", kind: "ledwall", x: 0.0, y: 0.0, w: 1.0, h: 0.50 },
      { label: "Breaking Callout", kind: "callout", x: 0.04, y: 0.55, w: 0.40, h: 0.15 },
      { label: "Lower Third", kind: "lower_third", x: 0.04, y: 0.80, w: 0.70, h: 0.10 },
      { label: "Ticker", kind: "ticker", x: 0.0, y: 0.92, w: 1.0, h: 0.06 },
    ],
    fourDCues: [
      { label: "Alert hit", tSec: 0, effect: "light_flash" },
    ],
    notes: ["Used only for breaking-news mock previews. Real broadcast is disabled."],
  },
  podcast: {
    label: "Podcast Room Preview",
    roomLabel: "Mougle Podcast Studio",
    layoutPreset: "podcast_two_host",
    camera: "anchor_two_shot",
    lighting: "podcast_intimate",
    aspect: "16:9",
    accent: "#a78bfa",
    lightingLabel: "Warm intimate key, soft rim",
    tickerText: "",
    lowerThirdText: "Mougle Podcast — Preview",
    avatars: [
      { label: "Host", role: "podcast_host", x: 0.32, y: 0.62, facing: "right" },
      { label: "Co-Host", role: "podcast_host", x: 0.58, y: 0.62, facing: "left" },
    ],
    panels: [
      { label: "Topic Monitor", kind: "monitor", x: 0.36, y: 0.10, w: 0.28, h: 0.30 },
      { label: "Lower Third", kind: "lower_third", x: 0.04, y: 0.82, w: 0.55, h: 0.10 },
    ],
    fourDCues: [],
    notes: ["Two-host default. Switch to host-guest from layout presets."],
  },
  debate: {
    label: "Debate Studio Preview",
    roomLabel: "Mougle Debate Arena",
    layoutPreset: "debate_three_person",
    camera: "panel_overview",
    lighting: "warm_studio",
    aspect: "16:9",
    accent: "#fbbf24",
    lightingLabel: "Balanced amber key on three positions",
    tickerText: "DEBATE • PREVIEW",
    lowerThirdText: "Debate — Mougle Network",
    avatars: [
      { label: "Side A", role: "guest", x: 0.20, y: 0.62, facing: "right" },
      { label: "Moderator", role: "debate_moderator", x: 0.45, y: 0.62, facing: "camera" },
      { label: "Side B", role: "guest", x: 0.70, y: 0.62, facing: "left" },
    ],
    panels: [
      { label: "LED Wall", kind: "ledwall", x: 0.04, y: 0.06, w: 0.92, h: 0.36 },
      { label: "Topic Panel", kind: "panel", x: 0.04, y: 0.46, w: 0.30, h: 0.12 },
      { label: "Lower Third", kind: "lower_third", x: 0.04, y: 0.82, w: 0.60, h: 0.10 },
      { label: "Ticker", kind: "ticker", x: 0.0, y: 0.92, w: 1.0, h: 0.06 },
    ],
    fourDCues: [
      { label: "Round start", tSec: 0, effect: "light_flash" },
      { label: "Round end", tSec: 120, effect: "color_change" },
    ],
    notes: ["Default three-person debate; moderator in center."],
  },
  interview: {
    label: "Interview Room Preview",
    roomLabel: "Mougle Interview Suite",
    layoutPreset: "podcast_host_guest",
    camera: "anchor_two_shot",
    lighting: "warm_studio",
    aspect: "16:9",
    accent: "#34d399",
    lightingLabel: "Warm interview key, soft rim",
    tickerText: "",
    lowerThirdText: "Interview — Mougle",
    avatars: [
      { label: "Host", role: "news_anchor", x: 0.30, y: 0.62, facing: "right" },
      { label: "Guest", role: "guest", x: 0.60, y: 0.62, facing: "left" },
    ],
    panels: [
      { label: "Topic Monitor", kind: "monitor", x: 0.38, y: 0.12, w: 0.24, h: 0.26 },
      { label: "Lower Third", kind: "lower_third", x: 0.04, y: 0.82, w: 0.55, h: 0.10 },
    ],
    fourDCues: [],
    notes: ["Default host + guest. Add a 3rd guest by editing avatar markers."],
  },
  market_watch: {
    label: "Market Watch Preview",
    roomLabel: "Mougle Market Watch Wall",
    layoutPreset: "market_wall",
    camera: "wide_master",
    lighting: "neutral_news",
    aspect: "21:9",
    accent: "#22d3ee",
    lightingLabel: "Neutral analytic key, cool fill",
    tickerText: "S&P • NDX • BTC • ETH • PREVIEW ONLY",
    lowerThirdText: "Market Watch — Mougle",
    avatars: [
      { label: "Analyst", role: "analyst", x: 0.20, y: 0.65, facing: "camera" },
    ],
    panels: [
      { label: "Wall Tile 1", kind: "monitor", x: 0.40, y: 0.10, w: 0.18, h: 0.34 },
      { label: "Wall Tile 2", kind: "monitor", x: 0.60, y: 0.10, w: 0.18, h: 0.34 },
      { label: "Wall Tile 3", kind: "monitor", x: 0.80, y: 0.10, w: 0.16, h: 0.34 },
      { label: "Ticker", kind: "ticker", x: 0.0, y: 0.92, w: 1.0, h: 0.06 },
    ],
    fourDCues: [],
    notes: ["Wide market wall. Tiles are placeholders — no live data feed."],
  },
  hall_event: {
    label: "Hall / Event Preview",
    roomLabel: "Mougle Event Hall",
    layoutPreset: "hall_stage",
    camera: "audience_reverse",
    lighting: "hall_event_spot",
    aspect: "16:9",
    accent: "#f472b6",
    lightingLabel: "Spotlit stage, warm front fill",
    tickerText: "",
    lowerThirdText: "Mougle Event — Preview",
    avatars: [
      { label: "Speaker", role: "virtual_ceo", x: 0.50, y: 0.55, facing: "camera" },
    ],
    panels: [
      { label: "Stage LED", kind: "ledwall", x: 0.10, y: 0.06, w: 0.80, h: 0.40 },
      { label: "Lower Third", kind: "lower_third", x: 0.10, y: 0.82, w: 0.50, h: 0.10 },
    ],
    fourDCues: [
      { label: "Spotlight up", tSec: 0, effect: "light_flash" },
      { label: "Applause cue", tSec: 30, effect: "fog_burst" },
    ],
    notes: ["Stage layout with speaker centered. No real lighting/4D hardware is sent."],
  },
  youtube_social: {
    label: "YouTube / Social Package Preview",
    roomLabel: "Social Vertical Cut",
    layoutPreset: "social_vertical_preview",
    camera: "social_vertical",
    lighting: "warm_studio",
    aspect: "9:16",
    accent: "#fb7185",
    lightingLabel: "Vertical-friendly soft key",
    tickerText: "@mougle • PREVIEW",
    lowerThirdText: "Mougle — Preview Clip",
    avatars: [
      { label: "Anchor", role: "news_anchor", x: 0.50, y: 0.58, facing: "camera" },
    ],
    panels: [
      { label: "Caption Bar", kind: "callout", x: 0.08, y: 0.16, w: 0.84, h: 0.10 },
      { label: "Lower Third", kind: "lower_third", x: 0.08, y: 0.78, w: 0.84, h: 0.10 },
    ],
    fourDCues: [],
    notes: ["9:16 social cut. No upload to YouTube or social platforms."],
  },
  fourd_cinema: {
    label: "4D Cinema Cue Preview",
    roomLabel: "Mougle 4D Theater",
    layoutPreset: "hall_stage",
    camera: "wide_master",
    lighting: "cinematic_dim",
    aspect: "21:9",
    accent: "#c084fc",
    lightingLabel: "Cinematic dim, accent washes",
    tickerText: "",
    lowerThirdText: "4D Cinema — Cue Plan",
    avatars: [],
    panels: [
      { label: "Cinema Screen", kind: "ledwall", x: 0.05, y: 0.06, w: 0.90, h: 0.50 },
    ],
    fourDCues: [
      { label: "Wind cue", tSec: 5, effect: "wind" },
      { label: "Fog burst", tSec: 12, effect: "fog_burst" },
      { label: "Color wash", tSec: 22, effect: "color_change" },
      { label: "Light flash", tSec: 30, effect: "light_flash" },
    ],
    notes: ["Cue planning only. No 4D hardware command is dispatched."],
  },
};

function buildScene(controls: PreviewStudioControls): PreviewStudioScene {
  const def = MODE_DEFAULTS[controls.mode];
  return {
    controls,
    avatars: def.avatars.map((a, i) => ({
      id: `av_${controls.mode}_${i + 1}`,
      label: a.label,
      role: a.role,
      x: a.x,
      y: a.y,
      facing: a.facing,
    })),
    panels: def.panels.map((p, i) => ({
      id: `pn_${controls.mode}_${i + 1}`,
      label: p.label,
      kind: p.kind,
      x: p.x, y: p.y, w: p.w, h: p.h,
    })),
    fourDCues: def.fourDCues.map((c, i) => ({
      id: `cue_${controls.mode}_${i + 1}`,
      label: c.label,
      tSec: c.tSec,
      effect: c.effect,
    })),
    cameraFrame: { aspect: def.aspect, label: controls.camera },
    lightingMood: { label: def.lightingLabel, accent: def.accent },
    notes: def.notes,
  };
}

function defaultControlsFor(mode: PreviewStudioMode): PreviewStudioControls {
  const d = MODE_DEFAULTS[mode];
  return {
    mode,
    layoutPreset: d.layoutPreset,
    camera: d.camera,
    lighting: d.lighting,
    roomLabel: d.roomLabel,
    showLowerThird: true,
    showTicker: d.tickerText.length > 0,
    showLedWall: d.panels.some((p) => p.kind === "ledwall"),
    show4dMarkers: d.fourDCues.length > 0,
    tickerText: d.tickerText,
    lowerThirdText: d.lowerThirdText,
  };
}

const SAFETY_LOCKED = {
  status: "draft" as const,
  approvalStatus: "draft" as const,
  visibility: "admin_only_internal" as const,
  publicUrl: null,
  signedUrl: null,
  realSendAllowed: false as const,
  executionEnabled: false as const,
  adminPreviewOnly: true as const,
  notRendered: true as const,
  notPublished: true as const,
  noUnrealExecution: true as const,
  noFourDHardware: true as const,
};

function sealState(scene: PreviewStudioScene): PreviewStudioState {
  return {
    id: `psv_${randomUUID()}`,
    createdAt: new Date().toISOString(),
    generatedBy: "root_admin",
    scene,
    ...SAFETY_LOCKED,
    safetyEnvelope: SAFETY_ENVELOPE,
  };
}

const states: PreviewStudioState[] = [];
let latest: PreviewStudioState | null = null;

export function getDefaultStudioScenes(): Record<PreviewStudioMode, PreviewStudioScene> {
  const out: Partial<Record<PreviewStudioMode, PreviewStudioScene>> = {};
  for (const m of PREVIEW_STUDIO_MODES) out[m] = buildScene(defaultControlsFor(m));
  return out as Record<PreviewStudioMode, PreviewStudioScene>;
}

export function getLatestPreviewStudioState(): PreviewStudioState {
  if (latest) return latest;
  const scene = buildScene(defaultControlsFor("newsroom"));
  latest = sealState(scene);
  states.push(latest);
  return latest;
}

export function generatePreviewStudioState(
  partial: Partial<PreviewStudioControls> & { mode: PreviewStudioMode },
): PreviewStudioState {
  const base = defaultControlsFor(partial.mode);
  const controls: PreviewStudioControls = { ...base, ...partial, mode: partial.mode };
  const scene = buildScene(controls);
  const sealed = sealState(scene);
  states.push(sealed);
  latest = sealed;
  return sealed;
}

export function updatePreviewStudioControls(
  partial: Partial<PreviewStudioControls>,
): PreviewStudioState {
  const current = getLatestPreviewStudioState();
  const merged: PreviewStudioControls = {
    ...current.scene.controls,
    ...partial,
    mode: partial.mode ?? current.scene.controls.mode,
  };
  const scene = buildScene(merged);
  const sealed = sealState(scene);
  states.push(sealed);
  latest = sealed;
  return sealed;
}

export function listPreviewStudioStates(): PreviewStudioState[] {
  return [...states];
}

export interface PreviewStudioTooltip {
  key: string;
  title: string;
  body: string;
}

export function getPreviewStudioTooltips(): PreviewStudioTooltip[] {
  return [
    { key: "preview_studio", title: "Preview Studio",
      body: "Admin-only mock preview. Nothing here renders or publishes." },
    { key: "production_wizard", title: "Production Wizard",
      body: "Guided steps to draft a production. Output stays internal until approved." },
    { key: "room_generator", title: "Room Generator",
      body: "Designs stage / room layouts for the preview canvas. Mock data only." },
    { key: "avatar_creator", title: "Avatar Creator",
      body: "Creates avatar markers. No real MetaHuman is built; no provider is called." },
    { key: "media_pipeline", title: "Media Pipeline",
      body: "Manages draft media packages. All assets stay internal." },
    { key: "asset_library", title: "Asset Library",
      body: "Internal-only library. No public URL / signed URL is ever created." },
    { key: "unreal_dry_run", title: "Unreal Dry-Run",
      body: "Validates a scene contract without sending any Unreal command." },
    { key: "fourd_sandbox", title: "4D Sandbox",
      body: "Plans 4D cues. No 4D hardware command is dispatched, ever." },
    { key: "publishing_disabled", title: "Publishing disabled",
      body: "Publishing is permanently disabled in this MVP. Manual root-admin override only." },
    { key: "mock_mode", title: "Mock mode",
      body: "All provider integrations are mocked. No outbound socket is opened." },
    { key: "draft_internal_only", title: "Draft / Internal only",
      body: "Every preview artifact is draft, admin-only, never public." },
  ];
}

export function _resetPreviewStudioForTests(): void {
  states.length = 0;
  latest = null;
}
