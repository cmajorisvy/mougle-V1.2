import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "http";
import express from "express";
import { registerPreviewStudioRoutes } from "../server/routes/preview-studio-routes";
import {
  _resetPreviewStudioForTests,
} from "../server/services/preview-studio-service";
import {
  PREVIEW_STUDIO_MODES,
  SAFETY_ENVELOPE,
  SafetyEnvelopeSchema,
} from "../shared/production-house";

let server: Server;
let base: string;
let allowAdmin = true;

before(async () => {
  const app = express();
  app.use(express.json());
  const requireRootAdmin = (_req: any, res: any, next: any) => {
    if (!allowAdmin) return res.status(401).json({ ok: false, error: "unauthorized" });
    next();
  };
  registerPreviewStudioRoutes(app, requireRootAdmin);
  // Mimic the production /api JSON 404 fallback so we can assert it.
  app.use("/{*path}", (req, res) => {
    if (req.originalUrl.startsWith("/api/") || req.originalUrl === "/api") {
      return res.status(404).json({ ok: false, error: "not_found" });
    }
    res.status(404).end();
  });
  server = createServer(app);
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  const addr = server.address();
  if (!addr || typeof addr === "string") throw new Error("no addr");
  base = `http://127.0.0.1:${addr.port}`;
});

after(async () => {
  await new Promise<void>((r) => server.close(() => r()));
});

beforeEach(() => {
  _resetPreviewStudioForTests();
  allowAdmin = true;
});

async function get(p: string) {
  return fetch(`${base}${p}`);
}
async function post(p: string, body: any) {
  return fetch(`${base}${p}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

const ROUTES = [
  { method: "GET",  path: "/api/admin/production-house/preview-studio/state" },
  { method: "GET",  path: "/api/admin/production-house/preview-studio/defaults" },
  { method: "GET",  path: "/api/admin/production-house/preview-studio/tooltips" },
  { method: "GET",  path: "/api/admin/production-house/preview-studio/history" },
  { method: "POST", path: "/api/admin/production-house/preview-studio/generate", body: { controls: { mode: "newsroom" } } },
  { method: "POST", path: "/api/admin/production-house/preview-studio/update-controls", body: { controls: { lowerThirdText: "hello" } } },
];

describe("Preview Studio — routes are real (not SPA fallback)", () => {
  it("missing /api route returns JSON 404 (not HTML)", async () => {
    const r = await get("/api/admin/production-house/preview-studio/does-not-exist");
    assert.equal(r.status, 404);
    const ct = r.headers.get("content-type") ?? "";
    assert.match(ct, /application\/json/);
    const body = await r.json();
    assert.equal(body.error, "not_found");
  });

  for (const route of ROUTES) {
    it(`${route.method} ${route.path} requires root-admin`, async () => {
      allowAdmin = false;
      try {
        const r = route.method === "GET"
          ? await get(route.path)
          : await post(route.path, route.body ?? {});
        assert.equal(r.status, 401);
        const ct = r.headers.get("content-type") ?? "";
        assert.match(ct, /application\/json/);
      } finally { allowAdmin = true; }
    });
  }
});

describe("Preview Studio — state & defaults", () => {
  it("GET /state returns JSON with a default scene when no generate has been called", async () => {
    const r = await get("/api/admin/production-house/preview-studio/state");
    assert.equal(r.status, 200);
    const body = await r.json();
    assert.equal(body.ok, true);
    assert.ok(body.state);
    assert.ok(body.state.scene);
    assert.ok(body.state.scene.controls);
  });

  it("GET /defaults returns a non-empty scene for every preview mode", async () => {
    const r = await get("/api/admin/production-house/preview-studio/defaults");
    const body = await r.json();
    assert.equal(body.ok, true);
    for (const m of PREVIEW_STUDIO_MODES) {
      const s = body.defaults[m];
      assert.ok(s, `missing default scene for ${m}`);
      assert.ok(s.controls && s.controls.mode === m);
      assert.ok(Array.isArray(s.panels) && s.panels.length >= 1);
      assert.ok(Array.isArray(s.avatars));
      assert.ok(Array.isArray(s.fourDCues));
      assert.ok(s.cameraFrame && s.lightingMood);
    }
  });

  it("GET /tooltips returns JSON with the expected keys", async () => {
    const r = await get("/api/admin/production-house/preview-studio/tooltips");
    const body = await r.json();
    assert.equal(body.ok, true);
    const keys = body.tooltips.map((t: any) => t.key);
    for (const k of [
      "preview_studio", "production_wizard", "room_generator", "avatar_creator",
      "media_pipeline", "asset_library", "unreal_dry_run", "fourd_sandbox",
      "publishing_disabled", "mock_mode", "draft_internal_only",
    ]) {
      assert.ok(keys.includes(k), `missing tooltip key ${k}`);
    }
  });
});

describe("Preview Studio — generate & update", () => {
  it("POST /generate works without env vars / providers", async () => {
    for (const k of [
      "OPENAI_API_KEY", "ELEVENLABS_API_KEY", "MESHY_API_KEY",
      "RUNWAY_API_KEY", "UNREAL_REMOTE_URL", "LOCAL_4D_BRIDGE_URL",
    ]) delete process.env[k];
    const r = await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "debate" },
    });
    const body = await r.json();
    assert.equal(r.status, 200);
    assert.equal(body.state.scene.controls.mode, "debate");
  });

  it("POST /update-controls merges control changes", async () => {
    await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "newsroom" },
    });
    const r = await post("/api/admin/production-house/preview-studio/update-controls", {
      controls: { lowerThirdText: "Custom anchor title" },
    });
    const body = await r.json();
    assert.equal(r.status, 200);
    assert.equal(body.state.scene.controls.lowerThirdText, "Custom anchor title");
    assert.equal(body.state.scene.controls.mode, "newsroom");
  });

  it("rejects invalid body with 400 JSON", async () => {
    const r = await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "not_a_real_mode" },
    });
    assert.equal(r.status, 400);
    const body = await r.json();
    assert.equal(body.error, "invalid_body");
  });
});

describe("Preview Studio — safety locks", () => {
  it("every state has the full set of safety-locked fields", async () => {
    const r = await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "podcast" },
    });
    const body = await r.json();
    const s = body.state;
    assert.equal(s.status, "draft");
    assert.equal(s.approvalStatus, "draft");
    assert.equal(s.visibility, "admin_only_internal");
    assert.equal(s.publicUrl, null);
    assert.equal(s.signedUrl, null);
    assert.equal(s.realSendAllowed, false);
    assert.equal(s.executionEnabled, false);
    assert.equal(s.adminPreviewOnly, true);
    assert.equal(s.notRendered, true);
    assert.equal(s.notPublished, true);
    assert.equal(s.noUnrealExecution, true);
    assert.equal(s.noFourDHardware, true);
  });

  it("client cannot override safety fields via generate body", async () => {
    const r = await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "podcast" },
      realSendAllowed: true,
      executionEnabled: true,
      publicUrl: "https://evil.example.com",
      signedUrl: "https://evil.example.com/signed",
      notPublished: false,
      status: "published",
    });
    const body = await r.json();
    assert.equal(body.state.realSendAllowed, false);
    assert.equal(body.state.executionEnabled, false);
    assert.equal(body.state.publicUrl, null);
    assert.equal(body.state.signedUrl, null);
    assert.equal(body.state.notPublished, true);
    assert.equal(body.state.status, "draft");
  });

  it("safetyEnvelope on every state equals SAFETY_ENVELOPE", async () => {
    const r = await post("/api/admin/production-house/preview-studio/generate", {
      controls: { mode: "fourd_cinema" },
    });
    const body = await r.json();
    assert.deepEqual(body.state.safetyEnvelope, SAFETY_ENVELOPE);
    assert.equal(SafetyEnvelopeSchema.safeParse(body.state.safetyEnvelope).success, true);
  });
});
