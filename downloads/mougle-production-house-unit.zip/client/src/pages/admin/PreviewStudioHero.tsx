import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Film,
  Wand2,
  Camera,
  Lightbulb,
  Tv2,
  Layers,
  ZapOff,
  ShieldAlert,
  ShieldCheck,
  RefreshCcw,
} from "lucide-react";

const PSV_API = "/api/admin/production-house/preview-studio";

const MODES: Array<{ id: PreviewMode; label: string; tip: string }> = [
  { id: "newsroom", label: "Newsroom", tip: "Anchor + LED wall + topic panel" },
  { id: "breaking_news", label: "Breaking News", tip: "Alert override layout" },
  { id: "podcast", label: "Podcast", tip: "Two-host or host-guest" },
  { id: "debate", label: "Debate", tip: "Three-person debate, moderator center" },
  { id: "interview", label: "Interview", tip: "Host + guest setup" },
  { id: "market_watch", label: "Market Watch", tip: "Multi-tile market wall" },
  { id: "hall_event", label: "Hall / Event", tip: "Stage layout for events" },
  { id: "youtube_social", label: "YouTube / Social", tip: "9:16 social cut preview" },
  { id: "fourd_cinema", label: "4D Cinema Cue", tip: "Cue planning (no hardware send)" },
];

const LAYOUT_PRESETS = [
  "anchor_center",
  "anchor_left_panel_right",
  "podcast_two_host",
  "podcast_host_guest",
  "debate_three_person",
  "debate_moderator_center",
  "hall_stage",
  "market_wall",
  "breaking_news_alert",
  "emergency_broadcast",
  "social_vertical_preview",
  "custom_grid",
] as const;

const CAMERA_PRESETS = [
  "wide_master",
  "anchor_two_shot",
  "anchor_close_up",
  "panel_overview",
  "audience_reverse",
  "social_vertical",
] as const;

const LIGHTING_PRESETS = [
  "neutral_news",
  "warm_studio",
  "breaking_high_contrast",
  "podcast_intimate",
  "hall_event_spot",
  "cinematic_dim",
] as const;

type PreviewMode =
  | "newsroom" | "breaking_news" | "podcast" | "debate" | "interview"
  | "market_watch" | "hall_event" | "youtube_social" | "fourd_cinema";

interface Marker { id: string; label: string; role?: string; x: number; y: number; facing?: string; }
interface Panel {
  id: string; label: string; kind: string;
  x: number; y: number; w: number; h: number;
}
interface Cue { id: string; label: string; tSec: number; effect: string; }
interface Scene {
  controls: {
    mode: PreviewMode; layoutPreset: string; camera: string; lighting: string;
    roomLabel: string; showLowerThird: boolean; showTicker: boolean;
    showLedWall: boolean; show4dMarkers: boolean;
    tickerText: string; lowerThirdText: string;
  };
  avatars: Marker[]; panels: Panel[]; fourDCues: Cue[];
  cameraFrame: { aspect: string; label: string; };
  lightingMood: { label: string; accent: string; };
  notes: string[];
}
interface PsvState {
  id: string; createdAt: string; generatedBy: string;
  scene: Scene;
  status: string; approvalStatus: string; visibility: string;
  publicUrl: null; signedUrl: null;
  realSendAllowed: false; executionEnabled: false;
  adminPreviewOnly: true; notRendered: true; notPublished: true;
  noUnrealExecution: true; noFourDHardware: true;
  safetyEnvelope: Record<string, boolean>;
}
interface TipData { key: string; title: string; body: string; }

async function jget<T>(p: string): Promise<T | null> {
  try {
    const r = await fetch(PSV_API + p, { credentials: "include" });
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch { return null; }
}
async function jpost<T>(p: string, body: any): Promise<T | null> {
  try {
    const r = await fetch(PSV_API + p, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch { return null; }
}

function tipFor(tips: TipData[] | null, key: string): string {
  if (!tips) return "";
  return tips.find((t) => t.key === key)?.body ?? "";
}

function Tip({ text, children }: { text: string; children: React.ReactNode }) {
  if (!text) return <>{children}</>;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span>{children}</span>
      </TooltipTrigger>
      <TooltipContent className="max-w-[280px] text-xs">{text}</TooltipContent>
    </Tooltip>
  );
}

export default function PreviewStudioHero() {
  const [state, setState] = useState<PsvState | null>(null);
  const [tips, setTips] = useState<TipData[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<PreviewMode>("newsroom");

  const refresh = async () => {
    setLoading(true);
    const [s, t] = await Promise.all([
      jget<{ ok: boolean; state: PsvState }>("/state"),
      jget<{ ok: boolean; tooltips: TipData[] }>("/tooltips"),
    ]);
    if (s?.state) {
      setState(s.state);
      setMode(s.state.scene.controls.mode);
    }
    if (t?.tooltips) setTips(t.tooltips);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  const loadMode = async (m: PreviewMode) => {
    setMode(m);
    setLoading(true);
    const r = await jpost<{ ok: boolean; state: PsvState }>("/generate", {
      controls: { mode: m },
    });
    if (r?.state) setState(r.state);
    setLoading(false);
  };

  const update = async (partial: Partial<Scene["controls"]>) => {
    setLoading(true);
    const r = await jpost<{ ok: boolean; state: PsvState }>("/update-controls", {
      controls: partial,
    });
    if (r?.state) setState(r.state);
    setLoading(false);
  };

  const scene = state?.scene;

  const aspect = scene?.cameraFrame.aspect ?? "16:9";
  const aspectClass = useMemo(() => {
    if (aspect === "9:16") return "aspect-[9/16] max-h-[460px] mx-auto";
    if (aspect === "1:1") return "aspect-square max-w-[520px] mx-auto";
    if (aspect === "21:9") return "aspect-[21/9]";
    return "aspect-video";
  }, [aspect]);

  return (
    <TooltipProvider delayDuration={200}>
      <section
        data-testid="preview-studio-hero"
        className="border-b border-slate-800/80 bg-gradient-to-b from-slate-950 via-slate-950/95 to-slate-950/70 px-6 pt-6 pb-5"
      >
        {/* Title */}
        <div className="flex items-start justify-between gap-4 flex-wrap mb-3">
          <div>
            <div className="flex items-center gap-2">
              <Film className="h-5 w-5 text-sky-400" />
              <Tip text={tipFor(tips, "preview_studio")}>
                <h2
                  data-testid="preview-studio-title"
                  className="text-xl font-bold tracking-tight bg-gradient-to-r from-sky-300 via-amber-200 to-rose-300 bg-clip-text text-transparent"
                >
                  Mougle Production Preview Studio
                </h2>
              </Tip>
            </div>
            <p
              data-testid="preview-studio-subtitle"
              className="text-xs text-slate-400 mt-1 max-w-2xl"
            >
              Admin-only 3D/4D development preview for rooms, avatars, panels,
              media packages, Unreal dry-run state, and 4D cue planning.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <Tip text={tipFor(tips, "draft_internal_only")}>
              <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 text-[10px] uppercase tracking-wider">
                <ShieldAlert className="h-3 w-3 mr-1" /> Admin Preview Only
              </Badge>
            </Tip>
            <Tip text={tipFor(tips, "draft_internal_only")}>
              <Badge variant="outline" className="border-rose-500/40 bg-rose-500/10 text-rose-300 text-[10px] uppercase tracking-wider">
                <ZapOff className="h-3 w-3 mr-1" /> Not Rendered
              </Badge>
            </Tip>
            <Tip text={tipFor(tips, "publishing_disabled")}>
              <Badge variant="outline" className="border-rose-500/40 bg-rose-500/10 text-rose-300 text-[10px] uppercase tracking-wider">
                <ZapOff className="h-3 w-3 mr-1" /> Not Published
              </Badge>
            </Tip>
            <Tip text={tipFor(tips, "unreal_dry_run")}>
              <Badge variant="outline" className="border-rose-500/40 bg-rose-500/10 text-rose-300 text-[10px] uppercase tracking-wider">
                <ZapOff className="h-3 w-3 mr-1" /> No Unreal Execution
              </Badge>
            </Tip>
            <Tip text={tipFor(tips, "fourd_sandbox")}>
              <Badge variant="outline" className="border-rose-500/40 bg-rose-500/10 text-rose-300 text-[10px] uppercase tracking-wider">
                <ZapOff className="h-3 w-3 mr-1" /> No 4D Hardware
              </Badge>
            </Tip>
            <Tip text={tipFor(tips, "mock_mode")}>
              <Badge variant="outline" className="border-sky-500/40 bg-sky-500/10 text-sky-300 text-[10px] uppercase tracking-wider">
                <ShieldCheck className="h-3 w-3 mr-1" /> Mock Mode
              </Badge>
            </Tip>
            <Button
              size="sm"
              variant="outline"
              data-testid="button-preview-studio-refresh"
              onClick={refresh}
              disabled={loading}
              className="border-slate-700 hover:border-sky-500/50"
            >
              <RefreshCcw className={`h-3.5 w-3.5 mr-1 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Persistent safety strip */}
        <div
          data-testid="preview-studio-safety-strip"
          className="text-[11px] text-amber-300/90 border border-amber-500/30 bg-amber-500/5 rounded-md px-3 py-2 mb-4"
        >
          Admin Preview Only — Not Rendered, Not Published, No Unreal Execution, No 4D Hardware.
        </div>

        {/* Layout: rail • canvas • inspector */}
        <div className="grid grid-cols-12 gap-4">
          {/* Left rail */}
          <aside
            data-testid="preview-studio-rail"
            className="col-span-12 md:col-span-3 space-y-3"
          >
            <div>
              <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
                <Wand2 className="h-3 w-3" /> Preview Mode
              </div>
              <div className="grid grid-cols-1 gap-1">
                {MODES.map((m) => (
                  <Tip key={m.id} text={m.tip}>
                    <button
                      data-testid={`mode-${m.id}`}
                      onClick={() => loadMode(m.id)}
                      className={`text-left text-xs px-2.5 py-1.5 rounded-md border transition ${
                        mode === m.id
                          ? "border-sky-500/50 bg-sky-500/10 text-sky-200"
                          : "border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/40"
                      }`}
                    >
                      {m.label}
                    </button>
                  </Tip>
                ))}
              </div>
            </div>

            {scene && (
              <>
                <RailSelect
                  testid="select-layout"
                  icon={<Layers className="h-3 w-3" />}
                  label="Layout Preset"
                  value={scene.controls.layoutPreset}
                  options={[...LAYOUT_PRESETS]}
                  onChange={(v) => update({ layoutPreset: v })}
                />
                <RailSelect
                  testid="select-camera"
                  icon={<Camera className="h-3 w-3" />}
                  label="Camera"
                  value={scene.controls.camera}
                  options={[...CAMERA_PRESETS]}
                  onChange={(v) => update({ camera: v })}
                />
                <RailSelect
                  testid="select-lighting"
                  icon={<Lightbulb className="h-3 w-3" />}
                  label="Lighting"
                  value={scene.controls.lighting}
                  options={[...LIGHTING_PRESETS]}
                  onChange={(v) => update({ lighting: v })}
                />
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
                    <Tv2 className="h-3 w-3" /> Overlays
                  </div>
                  <div className="space-y-1 text-xs">
                    <ToggleRow
                      testid="toggle-led"
                      label="LED Wall"
                      value={scene.controls.showLedWall}
                      onChange={(v) => update({ showLedWall: v })}
                    />
                    <ToggleRow
                      testid="toggle-lower-third"
                      label="Lower Third"
                      value={scene.controls.showLowerThird}
                      onChange={(v) => update({ showLowerThird: v })}
                    />
                    <ToggleRow
                      testid="toggle-ticker"
                      label="Ticker"
                      value={scene.controls.showTicker}
                      onChange={(v) => update({ showTicker: v })}
                    />
                    <ToggleRow
                      testid="toggle-4d"
                      label="4D Cue Markers"
                      value={scene.controls.show4dMarkers}
                      onChange={(v) => update({ show4dMarkers: v })}
                    />
                  </div>
                </div>
              </>
            )}
          </aside>

          {/* Canvas */}
          <div className="col-span-12 md:col-span-6 space-y-2">
            <div
              data-testid="preview-studio-canvas"
              className={`relative w-full rounded-lg border border-slate-800 bg-[radial-gradient(circle_at_center,#0f172a_0%,#020617_70%)] overflow-hidden ${aspectClass}`}
              style={{ boxShadow: scene ? `inset 0 0 80px ${scene.lightingMood.accent}22` : undefined }}
            >
              {scene ? (
                <>
                  {/* LED wall + panels */}
                  {scene.panels.map((p) => {
                    const visible =
                      (p.kind === "ledwall" && scene.controls.showLedWall) ||
                      (p.kind === "lower_third" && scene.controls.showLowerThird) ||
                      (p.kind === "ticker" && scene.controls.showTicker) ||
                      (p.kind !== "ledwall" && p.kind !== "lower_third" && p.kind !== "ticker");
                    if (!visible) return null;
                    return (
                      <div
                        key={p.id}
                        data-testid={`panel-${p.id}`}
                        className={`absolute border text-[10px] flex items-center justify-center uppercase tracking-wider ${
                          p.kind === "ledwall"
                            ? "border-sky-500/40 bg-sky-500/5 text-sky-200/80"
                            : p.kind === "ticker"
                            ? "border-amber-500/40 bg-amber-500/10 text-amber-200"
                            : p.kind === "lower_third"
                            ? "border-rose-500/40 bg-rose-500/10 text-rose-200"
                            : "border-slate-600/50 bg-slate-800/40 text-slate-300"
                        }`}
                        style={{
                          left: `${p.x * 100}%`,
                          top: `${p.y * 100}%`,
                          width: `${p.w * 100}%`,
                          height: `${p.h * 100}%`,
                        }}
                      >
                        {p.kind === "ticker"
                          ? scene.controls.tickerText || p.label
                          : p.kind === "lower_third"
                          ? scene.controls.lowerThirdText || p.label
                          : p.label}
                      </div>
                    );
                  })}

                  {/* Avatar markers */}
                  {scene.avatars.map((a) => (
                    <div
                      key={a.id}
                      data-testid={`avatar-${a.id}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2"
                      style={{ left: `${a.x * 100}%`, top: `${a.y * 100}%` }}
                    >
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-amber-400 to-rose-500 border-2 border-slate-100/70 flex items-center justify-center text-[10px] font-bold text-slate-900 shadow-lg">
                        {a.label.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="text-[9px] text-center text-slate-200 mt-1 font-medium">
                        {a.label}
                      </div>
                    </div>
                  ))}

                  {/* Camera frame badge */}
                  <div className="absolute top-2 left-2 text-[10px] px-2 py-0.5 rounded-md bg-slate-900/80 border border-slate-700 text-slate-200 flex items-center gap-1">
                    <Camera className="h-3 w-3" />
                    {scene.cameraFrame.label} • {scene.cameraFrame.aspect}
                  </div>
                  {/* Lighting badge */}
                  <div className="absolute top-2 right-2 text-[10px] px-2 py-0.5 rounded-md bg-slate-900/80 border border-slate-700 text-slate-200 flex items-center gap-1">
                    <Lightbulb className="h-3 w-3" />
                    {scene.controls.lighting}
                  </div>
                </>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-slate-500 text-sm">
                  Loading preview…
                </div>
              )}
            </div>

            {/* Timeline strip */}
            <div
              data-testid="preview-studio-timeline"
              className="rounded-md border border-slate-800 bg-slate-900/40 px-2 py-1.5"
            >
              <div className="flex items-center justify-between text-[10px] text-slate-500 uppercase tracking-wider mb-1">
                <span>Timeline</span>
                <span>Media • 4D • Camera • Panels</span>
              </div>
              <div className="relative h-6 bg-slate-950/60 rounded">
                {scene?.controls.show4dMarkers &&
                  scene.fourDCues.map((c) => (
                    <Tip key={c.id} text={`${c.label} @ ${c.tSec}s (${c.effect})`}>
                      <div
                        data-testid={`cue-${c.id}`}
                        className="absolute top-0 bottom-0 w-1 bg-rose-400/80"
                        style={{ left: `${Math.min(100, (c.tSec / 60) * 100)}%` }}
                      />
                    </Tip>
                  ))}
              </div>
            </div>
          </div>

          {/* Right inspector */}
          <aside
            data-testid="preview-studio-inspector"
            className="col-span-12 md:col-span-3 space-y-3 text-xs"
          >
            <InspectorBlock title="Room / Stage">
              <Row k="Room" v={scene?.controls.roomLabel ?? "—"} />
              <Row k="Mode" v={scene?.controls.mode ?? "—"} />
              <Row k="Layout" v={scene?.controls.layoutPreset ?? "—"} />
              <Row k="Aspect" v={scene?.cameraFrame.aspect ?? "—"} />
            </InspectorBlock>
            <InspectorBlock title="Avatars">
              {scene?.avatars.length
                ? scene.avatars.map((a) => (
                    <Row key={a.id} k={a.label} v={a.role ?? ""} />
                  ))
                : <div className="text-slate-500">none</div>}
            </InspectorBlock>
            <InspectorBlock title="Panels">
              {scene?.panels.map((p) => (
                <Row key={p.id} k={p.label} v={p.kind} />
              ))}
            </InspectorBlock>
            <InspectorBlock title="4D Cues">
              {scene?.fourDCues.length
                ? scene.fourDCues.map((c) => (
                    <Row key={c.id} k={`${c.tSec}s`} v={`${c.label} (${c.effect})`} />
                  ))
                : <div className="text-slate-500">none</div>}
            </InspectorBlock>
            <InspectorBlock title="Safety">
              <Row k="status" v={state?.status ?? "draft"} />
              <Row k="visibility" v={state?.visibility ?? "admin_only_internal"} />
              <Row k="publicUrl" v="null" />
              <Row k="signedUrl" v="null" />
              <Row k="realSendAllowed" v="false" />
              <Row k="executionEnabled" v="false" />
            </InspectorBlock>
          </aside>
        </div>
      </section>
    </TooltipProvider>
  );
}

function RailSelect({
  testid, icon, label, value, options, onChange,
}: {
  testid: string; icon: React.ReactNode; label: string;
  value: string; options: string[];
  onChange: (v: any) => void;
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
        {icon} {label}
      </div>
      <select
        data-testid={testid}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full text-xs px-2 py-1.5 rounded-md border border-slate-800 bg-slate-950 text-slate-200 hover:border-slate-700"
      >
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

function ToggleRow({
  testid, label, value, onChange,
}: { testid: string; label: string; value: boolean; onChange: (v: boolean) => void; }) {
  return (
    <button
      data-testid={testid}
      onClick={() => onChange(!value)}
      className="w-full flex items-center justify-between px-2 py-1 rounded border border-slate-800 hover:border-slate-700"
    >
      <span className="text-slate-300">{label}</span>
      <span className={value ? "text-emerald-300" : "text-slate-600"}>
        {value ? "ON" : "off"}
      </span>
    </button>
  );
}

function InspectorBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-slate-800 bg-slate-900/40 p-2">
      <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">{title}</div>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2">
      <span className="text-slate-500">{k}</span>
      <span className="text-slate-200 truncate text-right">{v}</span>
    </div>
  );
}
